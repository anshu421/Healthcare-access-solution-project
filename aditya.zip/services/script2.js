document.addEventListener("DOMContentLoaded", function () {
    const learnMoreButtons = document.querySelectorAll(".learn-more");
    
    learnMoreButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const service = button.parentElement;
            service.classList.toggle("expanded");
        });
    });
})