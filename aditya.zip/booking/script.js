document.addEventListener('DOMContentLoaded', () => {
    const appointmentForm = document.getElementById('appointment-form');
    const appointmentList = document.getElementById('appointment-list');

    appointmentForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const patientName = document.getElementById('patient-name').value;
        const doctorName = document.getElementById('doctor-name').value;
        const appointmentDate = document.getElementById('appointment-date').value;

        const listItem = document.createElement('li');
        listItem.innerText = `Patient's Name: ${patientName} With Doctor's Name: ${doctorName} on ${appointmentDate}`;
        appointmentList.appendChild(listItem);

        appointmentForm.reset();
    });
});