gsap.to("#test_h",{
    x:100,
    duration:2,
    delay:0.5,
    repeat:-1,
    yoyo:true
})

gsap.to("#anima",{
    x:30,
    duration:1,
    delay:0.5,
    repeat:-1,
    stagger:0.2,
    yoyo:true
    
})
gsap.to(".ani",{
    x:400,
    duration:1,
    delay:0.5,
    stagger:0.2
    
    
})
// gsap.registerPlugin(ScrollTrigger);

// gsap.to(".ani", {
//   x: 400,
//   duration: 1,
//   delay: 0.5,
//   stagger: 0.2,
//   scrollTrigger: {
//     trigger: ".ani",
//     start: "top center", // Adjust the start position as needed
//     end: "bottom center", // Adjust the end position as needed
//     markers: true, // Add markers for debugging
//     scrub: 1, // The animation will be scrubbed with the scroll
//   }
// });
