document.addEventListener('DOMContentLoaded', () => {
    const specializationSelect = document.getElementById('specialization-select');
    const doctorList = document.getElementById('doctor-list');

    specializationSelect.addEventListener('change', () => {
        const selectedSpecialization = specializationSelect.value;

        if (selectedSpecialization === 'all') {
            doctorList.querySelectorAll('.doctor-card').forEach(card => {
                card.style.display = 'block';
            });
        } else {
            // Filter doctors based on specialization
            doctorList.querySelectorAll('.doctor-card').forEach(card => {
                if (card.querySelector('p.specialization').textContent.toLowerCase().includes(selectedSpecialization)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    });
});